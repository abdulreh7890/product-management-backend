import express from "express"
import { createProduct, getProducts, getProduct, deleteProduct, updateProduct, getProductsByCategory } from "../Controllers/productController.js"
import upload from "../Middleware/uploads.js"
import verifyToken from "../Middleware/verifyToken.js"


const router = express.Router()

router.get("/products", getProducts)
router.get("/products/category/:name", getProductsByCategory)
router.get("/products/:id", getProduct)
router.post("/products", upload.single("image"),verifyToken ,createProduct )
router.delete("/products/:id", verifyToken, deleteProduct)
router.put("/products/:id", verifyToken, updateProduct)

export default router
